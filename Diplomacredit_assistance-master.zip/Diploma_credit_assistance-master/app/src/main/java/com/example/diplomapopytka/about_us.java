package com.example.diplomapopytka;



import android.app.Activity;
import android.os.Bundle;

public class about_us extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_us);

    }}